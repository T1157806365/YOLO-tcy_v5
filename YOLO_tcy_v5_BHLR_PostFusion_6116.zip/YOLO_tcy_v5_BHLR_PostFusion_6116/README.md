# YOLO-tcy_v5 / 61.16% 基线 / BHLR 融合后注入对照

本包仅对 `backup-20261031-teacher100` 的 `ga_monoalign_pcgrad` 实验代码做一次**可逆的 BHLR 注入位置变更**。不包含另一套训练器，不改 RGB/TIR Backbone、不改原 BHLR 细节编码器、不改 RLSFA-GTGA、不改 Mono Loss、KD 或 PCGrad。现有 `runs/`、`.pt` 权重不被删除或覆盖。

**重要：代码运行在服务器原来的项目目录** `/mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5`，无需创建另一个 YOLO 工程。由于无法访问服务器文件系统，本包需要你在服务器执行安装命令。补丁基于 GitHub 提交 `7d87ee5efbeaf1bac11176ad7fc3439ebc91829e` 的文件内容制作；如果你目前源码已被其他补丁改变，会拒绝匹配错误的源码，而不是盲目覆盖。

## 1. 安装（执行前先保存已有工作）

把 `YOLO_tcy_v5_BHLR_PostFusion_6116.zip` 上传到服务器，假设放在项目目录下。

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5

# 推荐创建本地实验分支；保留旧版提交可供恢复
# git switch -c exp-bhlr-postfusion-6116

mkdir -p /tmp/bhlr_postfusion_6116
unzip -oq YOLO_tcy_v5_BHLR_PostFusion_6116.zip -d /tmp/bhlr_postfusion_6116

python /tmp/bhlr_postfusion_6116/apply_postfusion_patch.py "$PWD" --check-only
python /tmp/bhlr_postfusion_6116/apply_postfusion_patch.py "$PWD"
python -m compileall -q models/rgbt_rlsfa_gtga_centered_bhlr_model.py \
  models/gtga_bhlr_factory.py ga_monoalign_pcgrad/val.py
```

安装前自动进行所有目标字符串匹配、Python 语法检查、YAML 配置生成检查，然后备份原来三个源码到 `patch_backups/bhlr_postfusion_6116_<timestamp>/`。旧 YAML 保留。新 YAML 已生成，不需要自己编写。

如果安装前使用了历史备份 YAML，需要注意：备份文件的 `model.rlsfa_gtga_centered.enabled` 曾为 `false`，但 `bhlr.guidance_mode: alignment`，无法初始化。**本包生成的两份对照配置都设为 `true`**，其余训练核心参数继承历史版本。

## 2. 精确改了什么

配置键 `model.bhlr.injection_position`：

- `pre_fusion`：旧路径 `RGB P3 -> BHLR -> RGB-T Add -> Neck`；旧 checkpoint 默认仍用这个路径。
- `post_fusion`：新路径 `RGB + aligned TIR -> BHLR -> Neck`。

BHLR 仍从 `RGB 1920`、`RGB semantic 640` 构造高分辨率残差；原 selector、对齐指导、`gamma_raw` 都不变。新结构只把 BHLR 的 `rgb_feat` 输入替换为**融合后 P3**，并将增强结果写回 fused P3 和 `fusion_features`。`rgb_backbone_raw` 不变，因此原有 RGB/TIR 辅助单模态损失的特征入口不变。

这个改动不会凭空增加预测信息，不能承诺 AP 上升；两种位置的 selector 输入分布不同，直接切换历史权重只能用于快速诊断，不等于完整的模型消融。

## 3. 先做同权重快速验证（不训练）

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
unset CUDA_VISIBLE_DEVICES

WEIGHTS=runs/ga_monoalign_pcgrad_100e/yolo26m_UAVCB_OfficialPT_MonoKD_PCGrad_100e_Step_seed0_v1_dualTeacherInit/weights/best.pt

# 历史路径 pre_fusion
python -m ga_monoalign_pcgrad.val --weights "$WEIGHTS" \
  --split val --device 3 --batch 4 --workers 4 --conf 0.001 --iou 0.70 \
  --bhlr-injection-position pre_fusion \
  --save-dir runs/bhlr_placement_probe/old_pre

# 同一 checkpoint，切换到融合后 BHLR，测试是否能正常工作
python -m ga_monoalign_pcgrad.val --weights "$WEIGHTS" \
  --split val --device 3 --batch 4 --workers 4 --conf 0.001 --iou 0.70 \
  --bhlr-injection-position post_fusion \
  --save-dir runs/bhlr_placement_probe/new_post

# 同一 checkpoint，关闭高分辨率残差：确认新路径的实际依赖性
python -m ga_monoalign_pcgrad.val --weights "$WEIGHTS" \
  --split val --device 3 --batch 4 --workers 4 --conf 0.001 --iou 0.70 \
  --bhlr-injection-position post_fusion --disable-bhlr-residual \
  --save-dir runs/bhlr_placement_probe/post_hr_off
```

注意：验证脚本默认拒绝覆盖已有 `metrics.json`，重跑请用新的 `--save-dir`。历史权重里的配置如果本身存在对齐开关冲突，则必须先对照保存配置排查；不要自行篡改 checkpoint 以使其能加载。

## 4. 两组匹配的 100e 训练（双 GPU 2/3）

生成的两份 YAML 分别为：

- `configs/experiments/ga_monoalign_pcgrad_v1/opt_v1_officialPT_single100_step_dualTeacherInit_BHLR_pre_fusion_100e.yaml`
- `configs/experiments/ga_monoalign_pcgrad_v1/opt_v1_officialPT_single100_step_dualTeacherInit_BHLR_post_fusion_100e.yaml`

它们使用同样的 `YOLO26m`、同样的 RGB/TIR 教师、同样的 Align / Mono / ROI KD / PCGrad 策略、同样的 100e schedule、相同 global batch=32 和 seed=0，**仅 BHLR 注入位置不同**。旧 `.pt` 不用于初始化新实验学生（仍按历史方案从两个单模态教师初始化），所以是公平匹配重训练。两组训练输出路径独立，避免覆盖历史最佳权重。

**训练融合前对照**：

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
mkdir -p logs pid
nohup python -u -m ga_monoalign_pcgrad.train \
  --cfg configs/experiments/ga_monoalign_pcgrad_v1/opt_v1_officialPT_single100_step_dualTeacherInit_BHLR_pre_fusion_100e.yaml \
  > logs/ga_bhlr_pre_fusion_100e.log 2>&1 &
echo $! > pid/ga_bhlr_pre_fusion_100e.pid
tail -n 20 -f logs/ga_bhlr_pre_fusion_100e.log
```

**训练融合后改进版**（建议确认对照可跑后启动） ：

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
mkdir -p logs pid
nohup python -u -m ga_monoalign_pcgrad.train \
  --cfg configs/experiments/ga_monoalign_pcgrad_v1/opt_v1_officialPT_single100_step_dualTeacherInit_BHLR_post_fusion_100e.yaml \
  > logs/ga_bhlr_post_fusion_100e.log 2>&1 &
echo $! > pid/ga_bhlr_post_fusion_100e.pid
tail -n 20 -f logs/ga_bhlr_post_fusion_100e.log
```

`train.device: '2,3'` 会沿用历史训练器的自动 DDP 子进程启动逻辑（不是在当前进程中把两卡合成一张）。确认日志含 `[DDP] Physical GPUs: [2, 3]` 和 rank0/rank1。两个实验如果并行会争抢同两块 GPU，请顺序跑。

**验证融合后模型**：

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
unset CUDA_VISIBLE_DEVICES
python -m ga_monoalign_pcgrad.val \
  --weights runs/ga_bhlr_placement_6116/yolo26m_UAVCB_dualTeacherInit_post_fusion_seed0/weights/best.pt \
  --split val --device 3 --batch 4 --workers 4 --conf 0.001 --iou 0.70 \
  --geometry-all --save-dir runs/bhlr_placement_eval/post_val
```

验证融合前对照，仅将权重路径中的 `post_fusion` 改成 `pre_fusion`，输出目录改为 `pre_val`。最终确定结构后再运行 Test，避免根据 Test 反复选模型。

## 5. 如何判定改进成立

1. 新旧位置各自重训练，在相同 Val 划分对比 AP50:95、AP75，不要把旧历史 Test 61.16% 直接当作新结构 Val 对照。
2. 在**同一新权重**下，额外对比 `--disable-bhlr-residual`；若 AP 差异极小，BHLR 仍可能被忽略。
3. 下一步再比较真实 1920 RGB 与伪高分辨率 RGB，确认收益来自额外空间细节，而非增加参数。此项没有包含在当前补丁里。

## 6. 回滚

不需要删除 `.pt` 或 `runs/`。如果在单独实验 Git 分支上，可以直接 `git switch` 回旧分支。若仅靠自动备份，请从 `patch_backups/bhlr_postfusion_6116_<timestamp>/` 将三个 Python 文件复制回原路径。新生成的 YAML 可保留作记录。

## 7. 验证范围

已核对 GitHub 历史提交中全部目标代码匹配点（model 10、factory 1、val 4），并检查补丁脚本的 Python 语法。**未在你的服务器上进行 Ultralytics / CUDA 真实前向、DDP 训练或 AP 评估**；请先执行 `--check-only`，然后运行 Val 快速验证。
