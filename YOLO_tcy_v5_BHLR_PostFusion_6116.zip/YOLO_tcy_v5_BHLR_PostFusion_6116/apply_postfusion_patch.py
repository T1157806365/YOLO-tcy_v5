#!/usr/bin/env python3
"""
Minimal, guarded in-place patch for YOLO-tcy_v5 61.16% historical code:
 - Keep existing BHLR residual/detail encoder/guidance intact
 - Add BHLR pre_fusion / post_fusion insertion switch
 - Preserve legacy checkpoint behavior (default pre_fusion)
 - Add optional ablation switches to ga_monoalign_pcgrad.val
 - Generate matched 100-epoch YAMLs from the old dualTeacherInit YAML.

Usage: python apply_postfusion_patch.py /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
"""
from __future__ import annotations
import argparse
import ast
import copy
from datetime import datetime
from pathlib import Path
import shutil
import sys

import yaml

REPO_REL = {
    'model': Path('models/rgbt_rlsfa_gtga_centered_bhlr_model.py'),
    'factory': Path('models/gtga_bhlr_factory.py'),
    'val': Path('ga_monoalign_pcgrad/val.py'),
}
ORIGINAL_YAML = Path('configs/experiments/ga_monoalign_pcgrad_v1/opt_v1_officialPT_single100_step_dualTeacherInit.yaml')
OUTPUT_DIR = Path('configs/experiments/ga_monoalign_pcgrad_v1')


def repl(src: str, needle: str, replacement: str, label: str, expected: int = 1) -> str:
    n = src.count(needle)
    if n != expected:
        raise RuntimeError(f'[{label}] expected {expected} source occurrences, got {n}. '
                           'File may differ from backup-20261031-teacher100; no changes written.')
    return src.replace(needle, replacement)


def patch_model(src: str) -> str:
    src = repl(src,
        '        bhlr_detach_alignment_guidance: bool = True,\n        verbose: bool = True,',
        '        bhlr_detach_alignment_guidance: bool = True,\n'
        '        bhlr_injection_position: str = "pre_fusion",\n'
        '        verbose: bool = True,', 'model parameter')

    src = repl(src, '        self.bhlr_enabled = bool(bhlr_enabled)\n',
        '        self.bhlr_enabled = bool(bhlr_enabled)\n'
        '        self.bhlr_injection_position = str(bhlr_injection_position).strip().lower()\n'
        '        if self.bhlr_injection_position not in {"pre_fusion", "post_fusion"}:\n'
        '            raise ValueError("bhlr_injection_position must be pre_fusion or post_fusion")\n',
        'model validation')

    # Keep pre_fusion semantically unchanged. In post_fusion path, compute fusion
    # first and let the SAME BHLR architecture add its detail residual there.
    src = repl(src,
        '        if use_bhlr:\n            detail_raw, reconstructed_high, residual_high = self.bhlr.build_lost_detail_bank(',
        '        # pre_fusion preserves the historical forward path exactly.\n'
        '        # post_fusion moves only the residual injection AFTER RGB-T fusion.\n'
        '        if self.bhlr_injection_position == "post_fusion":\n'
        '            fused_outputs, fusion_features = self.fuse_backbone_features(\n'
        '                rgb_outputs, aligned_tir\n'
        '            )\n'
        '        else:\n'
        '            fused_outputs, fusion_features = None, None\n\n'
        '        if use_bhlr:\n'
        '            detail_raw, reconstructed_high, residual_high = self.bhlr.build_lost_detail_bank(',
        'model initial fusion')

    src = repl(src,
        '            for scale in self.bhlr_scales:\n                layer_id = self.scale_to_index[scale]',
        '            # This reference is the ONLY change in BHLR feature injection.\n'
        '            bhlr_target_features = (\n'
        '                fused_outputs if self.bhlr_injection_position == "post_fusion"\n'
        '                else rgb_outputs\n'
        '            )\n'
        '            for scale in self.bhlr_scales:\n'
        '                layer_id = self.scale_to_index[scale]',
        'model target features')

    src = repl(src,
        '                    target_hw = rgb_outputs[layer_id].shape[-2:]',
        '                    target_hw = bhlr_target_features[layer_id].shape[-2:]',
        'model guidance shape')
    src = repl(src,
        '                        rgb_feat=rgb_outputs[layer_id],',
        '                        rgb_feat=bhlr_target_features[layer_id],',
        'model BHLR input (debug + non-debug)', expected=2)
    src = repl(src,
        '                    rgb_outputs[layer_id] = enhanced',
        '                    bhlr_target_features[layer_id] = enhanced',
        'model debug branch')
    src = repl(src,
        '                    rgb_outputs[layer_id] = self.bhlr.enhance_layer(',
        '                    bhlr_target_features[layer_id] = self.bhlr.enhance_layer(',
        'model non-debug branch')
    src = repl(src,
        '        fused_outputs, fusion_features = self.fuse_backbone_features(\n'
        '            rgb_outputs, aligned_tir\n'
        '        )\n',
        '        if self.bhlr_injection_position == "pre_fusion":\n'
        '            # Original path: BHLR enhanced RGB -> multimodal fusion.\n'
        '            fused_outputs, fusion_features = self.fuse_backbone_features(\n'
        '                rgb_outputs, aligned_tir\n'
        '            )\n'
        '        elif use_bhlr:\n'
        '            # The final P3 fusion feature must contain the enhanced tensor,\n'
        '            # not the pre-enhancement alias retained by fusion_features.\n'
        '            for scale in self.bhlr_scales:\n'
        '                layer_id = self.scale_to_index[scale]\n'
        '                fusion_features[layer_id] = fused_outputs[layer_id]\n',
        'model final fusion')

    src = repl(src,
        '            "bhlr_guidance_mode": self.bhlr_guidance_mode,',
        '            "bhlr_guidance_mode": self.bhlr_guidance_mode,\n'
        '            "bhlr_injection_position": self.bhlr_injection_position,',
        'model diagnostics')
    return src


def patch_factory(src: str) -> str:
    return repl(src,
        '            model_class = RGBTRLSFAGTGACenteredBHLRV2DetectionModel\n'
        '            model_extra = {}\n',
        '            model_class = RGBTRLSFAGTGACenteredBHLRV2DetectionModel\n'
        '            model_extra = {\n'
        '                "bhlr_injection_position": str(\n'
        '                    bhlr_cfg.get("injection_position", "pre_fusion")\n'
        '                )\n'
        '            }\n',
        'centered-model factory')


def patch_val(src: str) -> str:
    src = repl(src, 'import argparse,json\n', 'import argparse,json\nimport torch\n', 'val torch')
    src = repl(src,
        '    args=p.parse_args()\n',
        '    p.add_argument(\n'
        '        "--bhlr-injection-position",\n'
        '        default="checkpoint",\n'
        '        choices=("checkpoint", "pre_fusion", "post_fusion"),\n'
        '        help="For same-weight counterfactual tests only; does not change checkpoint",\n'
        '    )\n'
        '    p.add_argument(\n'
        '        "--disable-bhlr-residual",\n'
        '        action="store_true",\n'
        '        help="Zero BHLR gamma in-memory, leaving all other weights intact",\n'
        '    )\n'
        '    args=p.parse_args()\n',
        'val CLI')
    src = repl(src,
        '    model,ck,cfg=load_checkpoint(args.weights,device)\n',
        '    model,ck,cfg=load_checkpoint(args.weights,device)\n'
        '    if args.bhlr_injection_position != "checkpoint":\n'
        '        model.core.bhlr_injection_position = args.bhlr_injection_position\n'
        '    if args.disable_bhlr_residual:\n'
        '        if model.core.bhlr is None:\n'
        '            raise RuntimeError("Checkpoint has no BHLR module to disable")\n'
        '        with torch.no_grad():\n'
        '            for adapter in model.core.bhlr.adapters.values():\n'
        '                adapter.gamma_raw.zero_()\n'
        '    print("[ABLATION] BHLR injection:", model.core.bhlr_injection_position,\n'
        '          "residual_off:", args.disable_bhlr_residual, flush=True)\n',
        'val runtime override')
    src = repl(src,
        "    res={'split':args.split,'checkpoint':str(Path(args.weights).resolve()),",
        "    res={'split':args.split,'checkpoint':str(Path(args.weights).resolve()),\n"
        "         'bhlr_injection_position':model.core.bhlr_injection_position,\n"
        "         'bhlr_residual_disabled':bool(args.disable_bhlr_residual),",
        'val metadata')
    return src


def traincc(cfg_name: str, run_name: str) -> str:
    return f'''conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
mkdir -p logs pid
nohup python -u -m ga_monoalign_pcgrad.train \\
  --cfg configs/experiments/ga_monoalign_pcgrad_v1/{cfg_name} \\
  > logs/{run_name}.log 2>&1 &
echo $! > pid/{run_name}.pid
tail -n 20 -f logs/{run_name}.log
'''


def build_cfgs(original: dict) -> dict[Path, str]:
    result = {}
    for pos in ('pre_fusion', 'post_fusion'):
        cfg = copy.deepcopy(original)
        model = cfg['model']
        if model.get('variant') != 'rlsfa_gtga_centered_bhlr_v2':
            raise RuntimeError(f"Unexpected base model variant: {model.get('variant')}")
        # Original backup YAML had enabled: false despite guidance_mode: alignment.
        # Both matched configs must build a valid full alignment+BHLR network.
        model['rlsfa_gtga_centered']['enabled'] = True
        model['bhlr']['enabled'] = True
        model['bhlr']['injection_position'] = pos
        if model['bhlr'].get('guidance_mode') != 'alignment':
            raise RuntimeError('Historical guidance mode differs: expected alignment')
        cfg['loss']['alignment']['enabled'] = True
        cfg['train']['device'] = '2,3'
        cfg['train']['resume'] = None
        cfg['train']['init_student_weights'] = None
        cfg['output']['project'] = 'runs/ga_bhlr_placement_6116'
        cfg['output']['name'] = f'yolo26m_UAVCB_dualTeacherInit_{pos}_seed0'
        filename = f'opt_v1_officialPT_single100_step_dualTeacherInit_BHLR_{pos}_100e.yaml'
        cfg['traincc'] = traincc(filename, f'ga_bhlr_{pos}_100e')
        result[OUTPUT_DIR / filename] = yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('repo', nargs='?', default='/mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5')
    p.add_argument('--check-only', action='store_true', help='Check compatibility and syntax; write nothing')
    args = p.parse_args()
    repo = Path(args.repo).expanduser().resolve()
    inputs = {}
    new = {}
    for kind, rel in REPO_REL.items():
        path = repo / rel
        if not path.is_file():
            raise FileNotFoundError(f'Missing expected source: {path}')
        src = path.read_text(encoding='utf-8')
        if 'bhlr_injection_position' in src and kind == 'model':
            raise RuntimeError('Detected an already patched model: refuse double-apply')
        inputs[rel] = src
        fn = {'model': patch_model, 'factory': patch_factory, 'val': patch_val}[kind]
        edited = fn(src)
        ast.parse(edited, filename=str(path))
        new[rel] = edited
    oldcfg_path = repo / ORIGINAL_YAML
    if not oldcfg_path.is_file():
        raise FileNotFoundError(f'Missing historical YAML: {oldcfg_path}')
    sourcecfg = yaml.safe_load(oldcfg_path.read_text(encoding='utf-8'))
    cfgs = build_cfgs(sourcecfg)
    # Never overwrite any prior experiment configs.
    for rel in cfgs:
        if (repo / rel).exists():
            raise FileExistsError(f'Experiment YAML already exists: {repo / rel}')
    if args.check_only:
        print('[CHECK PASS] All source anchors matched, patched Python parses, matched YAMLs generated')
        for rel in new: print('  will modify:', rel)
        for rel in cfgs: print('  will create:', rel)
        return
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = repo / 'patch_backups' / f'bhlr_postfusion_6116_{stamp}'
    backup.mkdir(parents=True, exist_ok=False)
    for rel, src in inputs.items():
        dest = backup / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(src, encoding='utf-8')
    for rel, edited in new.items():
        path = repo / rel
        path.write_text(edited, encoding='utf-8')
        compile(path.read_text(encoding='utf-8'), str(path), 'exec')
    for rel, content in cfgs.items():
        path = repo / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
    print('[PATCH SUCCESS] Original code backed up:', backup)
    for rel in new: print('  modified:', rel)
    for rel in cfgs: print('  created:', rel)
    print('Original .pt files, original YAML and training outputs untouched.')
    print('Old checkpoints default to pre_fusion without changing their saved config.')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'[PATCH FAILED] {e}', file=sys.stderr)
        sys.exit(1)
