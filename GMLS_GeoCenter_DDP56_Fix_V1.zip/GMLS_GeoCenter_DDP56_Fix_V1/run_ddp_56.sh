#!/usr/bin/env bash
set -euo pipefail
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5

SOURCE="configs/experiments/gmls_v2_roi/uavcb_gmls_v2_hybrid_geo_center_scratch100_v2.yaml"
CONFIG="configs/experiments/gmls_v2_roi/uavcb_gmls_v2_hybrid_geo_center_scratch100_ddp56.yaml"
NAME="yolo26m_UAVCB_GMLSv2_Hybrid_GeoCenter_Scratch100_DDP56_seed0"

if [[ ! -f "$SOURCE" ]]; then
  echo "[ERROR] Missing installed GeoCenter V2 YAML: $SOURCE" >&2
  exit 1
fi

python - "$SOURCE" "$CONFIG" "$NAME" <<'PY'
import copy
import sys
from pathlib import Path
import yaml
src, dst, name = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
cfg = yaml.safe_load(src.read_text(encoding='utf-8'))
assert cfg['model']['roi_single_head']['topk'] == 2, 'Expected Top-2 model'
assert cfg['loss']['alignment']['lambda_final_center'] > 0, 'GeoCenter loss is missing'
assert cfg['model'].get('pretrained', True), 'Expected official YOLO26m pretrained initialization'
assert cfg['train'].get('resume', None) is None, 'Expected new training; resume must be null'
assert 'init_weights' not in cfg['train'], 'An old Hybrid checkpoint initialization is present'
cfg = copy.deepcopy(cfg)
cfg['train']['device'] = '5,6'            # Physical device ids
cfg['train']['batch'] = 8                # GLOBAL batch = 8, so microbatch/rank = 4
cfg['train']['accumulate'] = 4           # Effective global batch = 8*4 = 32
cfg['train']['epochs'] = 100
cfg['train']['resume'] = None
cfg['train']['workers'] = 4
cfg['output']['name'] = name
if dst.exists():
    old = yaml.safe_load(dst.read_text(encoding='utf-8'))
    if old != cfg:
        raise SystemExit(f'[ERROR] Config already exists and differs: {dst}; refusing to overwrite')
else:
    dst.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding='utf-8')
print('[DDP CONFIG]', dst)
print('[DEVICE] physical GPUs 5,6; 2 ranks; 4 samples/rank; accumulate=4; global effective batch=32')
print('[SCRATCH] 100 epochs; no old Hybrid checkpoint; official YOLO26m initialization retained')
PY

RUN="runs/gmls_v2_roi_hybrid/$NAME"
if [[ -e "$RUN/weights/last.pt" ]]; then
  echo "[ERROR] Found existing checkpoint $RUN/weights/last.pt. Not overwriting. Use a different run name." >&2
  exit 1
fi

if ! command -v torchrun >/dev/null 2>&1; then
  echo "[ERROR] torchrun unavailable in the current conda environment" >&2
  exit 1
fi

mkdir -p logs pid
LOG="logs/gmls_geo_center_scratch100_ddp56.log"
PID="pid/gmls_geo_center_scratch100_ddp56.pid"
if [[ -f "$PID" ]] && kill -0 "$(cat "$PID")" 2>/dev/null; then
  echo "[ERROR] Existing DDP launcher process is running: $(cat "$PID")" >&2
  exit 1
fi

# CUDA_VISIBLE_DEVICES maps physical GPU 5->cuda:0 and GPU 6->cuda:1.
# torchrun sets WORLD_SIZE=2 and LOCAL_RANK=0/1. Passing device '0,1'
# documents the remapped indices; setup_distributed actually uses LOCAL_RANK.
CUDA_VISIBLE_DEVICES=5,6 \
nohup torchrun --standalone --nnodes=1 --nproc_per_node=2 \
  train_gmls_v2_roi_hybrid.py \
  --cfg "$CONFIG" \
  --device 0,1 \
  > "$LOG" 2>&1 &
PID_VALUE=$!
echo "$PID_VALUE" > "$PID"
echo "[STARTED] torchrun pid=$PID_VALUE"
echo "[LOG] $LOG"
echo "[CHECK] grep -m1 'ONE HEAD V2 HYBRID' '$LOG'"
echo "[TAIL] tail -f '$LOG'"
