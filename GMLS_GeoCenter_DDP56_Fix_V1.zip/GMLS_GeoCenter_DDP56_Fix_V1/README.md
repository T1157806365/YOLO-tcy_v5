# GeoCenter Scratch 100 — GPU 5+6 DDP correction

Fixes the incorrect single-GPU `--device 3` launch from GeoCenter Scratch100 V2. Does not change model source or the previously installed loss patch.

## Setup

```bash
conda activate tcy
cd /mnt/sda/taochangyong/Projects/Model/YOLO-tcy_v5
unzip -o GMLS_GeoCenter_DDP56_Fix_V1.zip -d .
nvidia-smi -i 5,6 --query-gpu=index,memory.total,memory.used,memory.free --format=csv
bash GMLS_GeoCenter_DDP56_Fix_V1/run_ddp_56.sh
tail -f logs/gmls_geo_center_scratch100_ddp56.log
```

## Correct training launch

Uses `CUDA_VISIBLE_DEVICES=5,6 torchrun --standalone --nnodes=1 --nproc_per_node=2`; physical GPU 5 corresponds to rank 0 / cuda:0, physical GPU 6 corresponds to rank 1 / cuda:1. `--device 0,1` means *remapped CUDA indices* with the visibility environment variable set.

Train config is a new file, `configs/experiments/gmls_v2_roi/uavcb_gmls_v2_hybrid_geo_center_scratch100_ddp56.yaml`. Training from scratch (official YOLO pretrained only), 100 epochs; global microbatch 8 -> 4/rank, accumulate 4 -> effective global batch 32. GT-assisted ROI schedule, Top2 selector, and final-center loss are preserved.

The new training run is `runs/gmls_v2_roi_hybrid/yolo26m_UAVCB_GMLSv2_Hybrid_GeoCenter_Scratch100_DDP56_seed0`.

If even 4/rank OOMs when GPUs 5 and 6 are otherwise free, set `train.batch: 4` and `train.accumulate: 8` in the new YAML, then rerun (2/rank, same effective batch). Do not modify `model.py`, old checkpoints, or stop unknown GPU processes.

Expected log: `world=2 microbatch/rank=4 accumulate=4 effective_batch≈32 epochs=100 resume=False start_epoch=0`.
